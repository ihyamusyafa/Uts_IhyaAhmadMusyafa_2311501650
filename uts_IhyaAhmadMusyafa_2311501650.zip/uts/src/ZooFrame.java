import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;

public class ZooFrame extends JFrame {
    private ArrayList<Animal> zooList;
    private JPanel mainPanel;
    private CardLayout cardLayout;

    // Komponen Daftar Hewan
    private DefaultListModel<Animal> listModel;
    private JList<Animal> animalJList;

    public ZooFrame() {
        zooList = new ArrayList<>();
        listModel = new DefaultListModel<>();

        setTitle("Digital Zoo Manager");
        setSize(450, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        cardLayout = new CardLayout();
        mainPanel = new JPanel(cardLayout);

        // --- Panel 1: Menu Utama ("Animals") ---
        JPanel homePanel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.gridx = 0; gbc.gridy = 0;

        JLabel titleLabel = new JLabel("ANIMALS");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 24));
        homePanel.add(titleLabel, gbc);

        gbc.gridy = 1;
        JButton mammalsBtn = new JButton("Mammals");
        mammalsBtn.setPreferredSize(new Dimension(150, 40));
        homePanel.add(mammalsBtn, gbc);

        gbc.gridy = 2;
        JButton birdsBtn = new JButton("Bird");
        birdsBtn.setPreferredSize(new Dimension(150, 40));
        homePanel.add(birdsBtn, gbc);

        // --- Panel 2: Sub-Menu Mamalia (Cat & Cow) ---
        JPanel mammalMenuPanel = new JPanel(new GridBagLayout());
        gbc.gridy = 0;
        mammalMenuPanel.add(new JLabel("Select a Mammal:"), gbc);

        gbc.gridy = 1;
        JButton catBtn = new JButton("Cat");
        mammalMenuPanel.add(catBtn, gbc);

        gbc.gridy = 2;
        JButton cowBtn = new JButton("Cow ");
        mammalMenuPanel.add(cowBtn, gbc);

        gbc.gridy = 3;
        JButton backFromMammal = new JButton("<- Back");
        mammalMenuPanel.add(backFromMammal, gbc);

        // --- Panel 3: Sub-Menu Burung (Parrot & Duck) ---
        JPanel birdMenuPanel = new JPanel(new GridBagLayout());
        gbc.gridy = 0;
        birdMenuPanel.add(new JLabel("Select a Bird:"), gbc);

        gbc.gridy = 1;
        JButton parrotBtn = new JButton("Parrot");
        birdMenuPanel.add(parrotBtn, gbc);

        gbc.gridy = 2;
        JButton duckBtn = new JButton("Duck");
        birdMenuPanel.add(duckBtn, gbc);

        gbc.gridy = 3;
        JButton backFromBird = new JButton("<- Back");
        birdMenuPanel.add(backFromBird, gbc);

        // --- Panel 4: Tampilan Daftar Koleksi Zoo & Suara ---
        JPanel zooViewPanel = new JPanel(new BorderLayout(10, 10));
        zooViewPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        animalJList = new JList<>(listModel);
        // Custom renderer agar tampil nama & jenis hewannya dengan rapi
        animalJList.setCellRenderer(new DefaultListCellRenderer() {
            @Override
            public Component getListCellRendererComponent(JList<?> list, Object value, int index, boolean isSelected, boolean cellHasFocus) {
                Component c = super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);
                if (value instanceof Animal) {
                    Animal a = (Animal) value;
                    setText(a.getName() + " (" + a.getClass().getSimpleName() + ") - Click to hear sound!");
                }
                return c;
            }
        });

        zooViewPanel.add(new JLabel("Your Zoo Collection (Click animal to hear sound):", JLabel.CENTER), BorderLayout.NORTH);
        zooViewPanel.add(new JScrollPane(animalJList), BorderLayout.CENTER);

        JButton backToHome = new JButton("Back to Main Menu");
        zooViewPanel.add(backToHome, BorderLayout.SOUTH);

        // Masukkan semua panel ke CardLayout
        mainPanel.add(homePanel, "HOME");
        mainPanel.add(mammalMenuPanel, "MAMMAL_MENU");
        mainPanel.add(birdMenuPanel, "BIRD_MENU");
        mainPanel.add(zooViewPanel, "ZOO_VIEW");

        add(mainPanel);

        // --- EVENT HANDLING (Navigasi Tombol) ---
        mammalsBtn.addActionListener(e -> cardLayout.show(mainPanel, "MAMMAL_MENU"));
        birdsBtn.addActionListener(e -> cardLayout.show(mainPanel, "BIRD_MENU"));

        backFromMammal.addActionListener(e -> cardLayout.show(mainPanel, "HOME"));
        backFromBird.addActionListener(e -> cardLayout.show(mainPanel, "HOME"));
        backToHome.addActionListener(e -> cardLayout.show(mainPanel, "HOME"));

        // Aksi ketika tombol Cat diklik -> Memanggil static nested class Mammal.Cat
        catBtn.addActionListener(e -> {
            Mammal.Cat cat = new Mammal.Cat("Jojo", 2, "White");
            zooList.add(cat);
            listModel.addElement(cat);
            cardLayout.show(mainPanel, "ZOO_VIEW");
        });

        // Aksi ketika tombol Cow diklik -> Memanggil static nested class Mammal.Cow
        cowBtn.addActionListener(e -> {
            Mammal.Cow cow = new Mammal.Cow("Saepul", 4, "Black & White");
            zooList.add(cow);
            listModel.addElement(cow);
            cardLayout.show(mainPanel, "ZOO_VIEW");
        });

        // Aksi ketika tombol Parrot diklik -> Memanggil static nested class Bird.Parrot
        parrotBtn.addActionListener(e -> {
            Bird.Parrot parrot = new Bird.Parrot("Gatot", 1, true);
            zooList.add(parrot);
            listModel.addElement(parrot);
            cardLayout.show(mainPanel, "ZOO_VIEW");
        });

        // Aksi ketika tombol Duck diklik -> Memanggil static nested class Bird.Duck
        duckBtn.addActionListener(e -> {
            Bird.Duck duck = new Bird.Duck("Ben", 2, true);
            zooList.add(duck);
            listModel.addElement(duck);
            cardLayout.show(mainPanel, "ZOO_VIEW");
        });

        // Aksi KLIK pada daftar hewan di JList untuk memunculkan suara
        animalJList.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                Animal selectedAnimal = animalJList.getSelectedValue();
                if (selectedAnimal != null) {
                    JOptionPane.showMessageDialog(ZooFrame.this,
                            selectedAnimal.getName() + " says: \"" + selectedAnimal.makeSound() + "\"",
                            "Animal Sound",
                            JOptionPane.INFORMATION_MESSAGE);
                }
            }
        });
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new ZooFrame().setVisible(true));
    }
}