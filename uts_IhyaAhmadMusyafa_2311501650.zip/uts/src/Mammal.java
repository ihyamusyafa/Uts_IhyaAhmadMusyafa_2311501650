public class Mammal extends Animal {
    private String furColor;

    public Mammal(String name, int age, String furColor) {
        super(name, age);
        this.furColor = furColor;
    }

    public String getFurColor() {
        return furColor;
    }

    @Override
    public String makeSound() {
        return "The mammal makes a sound.";
    }

    @Override
    public String getInfo() {
        return super.getInfo() + ", Fur Color: " + furColor;
    }

    // --- Static Nested Class untuk Cat ---
    public static class Cat extends Mammal {
        public Cat(String name, int age, String furColor) {
            super(name, age, furColor);
        }

        @Override
        public String makeSound() {
            return "Meoww!";
        }
    }

    // --- Static Nested Class untuk Cow ---
    public static class Cow extends Mammal {
        public Cow(String name, int age, String furColor) {
            super(name, age, furColor);
        }

        @Override
        public String makeSound() {
            return "Mooo!";
        }
    }
}