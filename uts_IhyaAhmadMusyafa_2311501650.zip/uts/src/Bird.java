public class Bird extends Animal {
    private boolean canFly;

    public Bird(String name, int age, boolean canFly) {
        super(name, age);
        this.canFly = canFly;
    }

    public boolean isCanFly() {
        return canFly;
    }

    @Override
    public String makeSound() {
        return "The bird chirps.";
    }

    @Override
    public String getInfo() {
        return super.getInfo() + ", Can Fly: " + (canFly ? "Yes" : "No");
    }

    // --- Static Nested Class untuk Parrot ---
    public static class Parrot extends Bird {
        public Parrot(String name, int age, boolean canFly) {
            super(name, age, canFly);
        }

        @Override
        public String makeSound() {
            return "Squawk! Hello!";
        }
    }

    // --- Static Nested Class untuk Duck ---
    public static class Duck extends Bird {
        public Duck(String name, int age, boolean canFly) {
            super(name, age, canFly);
        }

        @Override
        public String makeSound() {
            return "Quack quack!";
        }
    }
}