public class Animal {
    private String name;
    private int age;

    public Animal(String name, int age) {
        this.name = name;
        this.age = age;
    }

    public String getName() {
        return name;
    }

    public int getAge() {
        return age;
    }

    public String makeSound() {
        return "The animal makes a sound.";
    }

    public String getInfo() {
        return "Name: " + name + ", Age: " + age;
    }
}